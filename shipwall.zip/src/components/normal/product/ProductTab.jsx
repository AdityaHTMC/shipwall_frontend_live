import React from 'react'
import './../../../css/mix.css'

const ProductTab = () => {
  return (
    <>
    {/* <div className="tp-product-tab tp-product-tab-border tp-tab d-flex justify-content-md-end">
    <ul
      className="nav nav-tabs justify-content-sm-end"
      id="productTab"
      role="tablist"
    >
      <li className="nav-item" role="presentation">
        <button
          className="nav-link active"
          id="new-tab"
          data-bs-toggle="tab"
          data-bs-target="#new-tab-pane"
          type="button"
          role="tab"
          aria-controls="new-tab-pane"
          aria-selected="true"
        >
          New
          <span className="tp-product-tab-line">
            <svg width={52} height={13} viewBox="0 0 52 13" fill="none">
              <path
                d="M1 8.97127C11.6061 -5.48521 33 3.99996 51 11.4635"
                stroke="currentColor"
                strokeWidth={2}
                strokeMiterlimit="3.8637"
                strokeLinecap="round"
              />
            </svg>
          </span>
        </button>
      </li>
      <li className="nav-item" role="presentation">
        <button
          className="nav-link"
          id="featured-tab"
          data-bs-toggle="tab"
          data-bs-target="#featured-tab-pane"
          type="button"
          role="tab"
          aria-controls="featured-tab-pane"
          aria-selected="false"
        >
          Featured
          <span className="tp-product-tab-line">
            <svg width={52} height={13} viewBox="0 0 52 13" fill="none">
              <path
                d="M1 8.97127C11.6061 -5.48521 33 3.99996 51 11.4635"
                stroke="currentColor"
                strokeWidth={2}
                strokeMiterlimit="3.8637"
                strokeLinecap="round"
              />
            </svg>
          </span>
        </button>
      </li>
      <li className="nav-item" role="presentation">
        <button
          className="nav-link"
          id="topsell-tab"
          data-bs-toggle="tab"
          data-bs-target="#topsell-tab-pane"
          type="button"
          role="tab"
          aria-controls="topsell-tab-pane"
          aria-selected="false"
        >
          Top Sellers
          <span className="tp-product-tab-line">
            <svg width={52} height={13} viewBox="0 0 52 13" fill="none">
              <path
                d="M1 8.97127C11.6061 -5.48521 33 3.99996 51 11.4635"
                stroke="currentColor"
                strokeWidth={2}
                strokeMiterlimit="3.8637"
                strokeLinecap="round"
              />
            </svg>
          </span>
        </button>
      </li>
    </ul>
  </div> */}
    </>
  )
}

export default ProductTab
